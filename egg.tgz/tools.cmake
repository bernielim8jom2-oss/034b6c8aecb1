# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(cache-warmup src/cache-warmup.cpp)
set_property(TARGET cache-warmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-warmup lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(cycles-per-byte src/cycles-per-byte.cpp)
set_property(TARGET cycles-per-byte PROPERTY CXX_STANDARD 11)
target_link_libraries(cycles-per-byte lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(boundary-tests src/boundary-tests.cpp)
set_property(TARGET boundary-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(boundary-tests lionss pthread)

add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(docs-examples src/docs-examples.cpp)
set_property(TARGET docs-examples PROPERTY CXX_STANDARD 11)
target_link_libraries(docs-examples lionss pthread)

add_executable(leap-second-tests src/leap-second-tests.cpp)
set_property(TARGET leap-second-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(leap-second-tests lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(sdist-build src/sdist-build.cpp)
set_property(TARGET sdist-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sdist-build lionss pthread)

add_executable(pch-build src/pch-build.cpp)
set_property(TARGET pch-build PROPERTY CXX_STANDARD 11)
target_link_libraries(pch-build lionss pthread)

add_executable(coverage src/coverage.cpp)
set_property(TARGET coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage lionss pthread)

add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

