// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("static binary\n", stdout);
  return lionss_run_workload("static-binary");
}
