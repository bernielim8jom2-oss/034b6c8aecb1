// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("coverage\n", stdout);
  return lionss_run_workload("coverage");
}
