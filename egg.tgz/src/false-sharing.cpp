// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("false sharing"); }
int main(){
  announce();
  return lionss_run_workload("false-sharing");
}
