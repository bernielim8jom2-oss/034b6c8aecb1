// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("core dump test"); }
int main(){
  announce();
  return lionss_run_workload("core-dump-test");
}
