// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("endianness check"); }
int main(){
  announce();
  return lionss_run_workload("endianness-check");
}
