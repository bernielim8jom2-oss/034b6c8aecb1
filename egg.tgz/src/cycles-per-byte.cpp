// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cycles per byte\n", stdout);
  return lionss_run_workload("cycles-per-byte");
}
