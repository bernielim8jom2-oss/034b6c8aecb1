// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("dependency graph"); }
int main(){
  announce();
  return lionss_run_workload("dependency-graph");
}
