// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("docs examples\n", stdout);
  return lionss_run_workload("docs-examples");
}
